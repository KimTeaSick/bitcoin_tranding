my_list = [1, 2, 3, 4, 5]
to_keep = [2, 4, 7]

result = list(filter(lambda x: x in to_keep, my_list))
print(result)  # Output: [2, 4]