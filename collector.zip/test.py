import requests
import datetime
from database import engine, SessionLocal
from sqlalchemy.orm import Session
import models
import threading
import pandas as pd

try:
    db = SessionLocal()
    db: Session
finally:
    db.close()

Price = []
macdCollector = []
fitCoins = []

now = datetime.datetime.now()

now1 = datetime.datetime.now()

coinList = db.query(models.coinList).all()


for coin in coinList:
    if coin.delflag == 1:
        continue
    url = f"https://api.bithumb.com/public/candlestick/{coin.coin_name}/1m"
    response = requests.get(url)
    data = response.json()["data"]

    time = datetime.datetime.now()

    try:
        # 데이터프레임 df 생성
        df = pd.DataFrame(data, columns=['time', 'open', 'close', 'high', 'low', 'volume'])
        df2 = df['time']

        df['time'] = pd.to_datetime(df['time'], unit='ms') + datetime.timedelta(hours=9)

        # 빈 시간 0 채움
        df = df.set_index('time').resample('1T').asfreq()
        df = df.fillna(0)

        # insert 할 내용 append
        for index, row in df.iterrows():
            print(row[index])
            #print('close: ',row['close'], '========================================================================')
            #Price.append({'STime' : int(data2[0]/1000), 'Open': data2[1], 'Close': data2[2], 'High': data2[3], 'Low':data2[4], 'Volume': data2[5], 'coin_name': data2[6], 'time': data2[7]})

    except Exception as e:
        print(e)


db.bulk_insert_mappings(models.coinMinPrice, currentPrice)
db.commit()

now2 = datetime.datetime.now()
print(f'Running Time: {now2 - now1}')
